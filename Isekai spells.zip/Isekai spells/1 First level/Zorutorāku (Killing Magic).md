**Level:** 1st  
**Casting Time:** 1 action  
**Range/Area:** 120 ft  
**Components:** V, S  
**Duration:** Instantaneous  
**School:** Evocation  
**Attack/Save:** Ranged Spell Attack  
**Damage/Effect:** Variable

**Spell Description:**  
Zorutorāku, or Killing Magic, is a highly adaptable spell that allows you to conjure magical energy and shape it into projectiles of destructive power. Upon casting, you choose the damage type (fire, ice, lightning, acid, or necrotic) and the spell's configuration, affecting its damage output and targeting mechanism.

**Configurations:**

- **Single Target (High Precision):** You focus the spell's energy into a single, potent projectile aimed at one creature or object within range. Make a ranged spell attack against the target. On a hit, the target takes 1d10 damage of the chosen type.
    
- **Dual Projectiles (Balanced):** You split the spell's energy into two projectiles, each targeting a creature or object of your choice within range (you can target the same creature or two different creatures). Make separate ranged spell attacks for each projectile. Each hit deals 1d6 damage of the chosen type.
    
- **Triple Spread (Area Coverage):** You diffuse the spell's energy into three smaller, less focused projectiles that must be directed at targets within 10 feet of each other. Make separate ranged spell attacks for each projectile. Each hit deals 1d4 damage of the chosen type.
    

**At Higher Levels.** When you cast this spell using a spell slot of 2nd level or higher, you can create one additional projectile for each slot level above 1st. The damage for each configuration increases as follows: Single Target remains 1d10 (due to its high precision nature), Dual Projectiles increase to 1d8 per projectile, and Triple Spread increases to 1d6 per projectile.