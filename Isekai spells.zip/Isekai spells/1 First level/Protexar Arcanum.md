**Level:** 1st  
**Casting Time:** 1 reaction, which you take when you or a creature within 30 feet of you is targeted by a spell  
**Range/Area:** Self or 30 ft  
**Components:** V, S  
**Duration:** 1 round  
**School:** Abjuration  
**Attack/Save:** None  
**Damage/Effect:** Protection/Reflection

**Spell Description:**  
Protexar Arcanum conjures a hexagonal magical barrier that serves as a bulwark against magical assaults, manifesting instantaneously to protect you or an ally. This spell is designed with modularity in mind, allowing you to adjust its size and shape at the time of casting, which in turn, affects its capacity to block and reflect magical energy.

Upon casting, choose the barrier's configuration:

- **Large Shield:** Forms a large hexagonal barrier that covers a 10-foot diameter. It can absorb and nullify up to 10 points of damage from any spell level 1 or higher, but it cannot reflect any spells back.
- **Medium Shield:** Creates a medium-sized hexagon with a 5-foot diameter. It absorbs and nullifies up to 15 points of spell damage and reflects the first 5 points of absorbed spell damage back to the caster.
- **Small Shield:** Generates a small, focused barrier with a 2-foot diameter, placed in the direction of the incoming spell. It absorbs and nullifies up to 20 points of spell damage and reflects the first 10 points of absorbed spell damage back to the caster.

The Protexar Arcanum cannot block physical attacks or effects that aren't classified as spells (e.g., breath weapons, natural abilities). The barrier disappears after it has absorbed damage or at the start of your next turn.

**At Higher Levels.** When you cast this spell using a spell slot of 2nd level or higher, the damage absorption capacity increases by 10 points, and the reflection capacity increases by 1 points for each slot level above 1st.