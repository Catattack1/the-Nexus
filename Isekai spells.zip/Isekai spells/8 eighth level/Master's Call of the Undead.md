**Level:** 8th  
**Casting Time:** 1 hour  
**Range/Area:** 10 ft  
**Components:** V, S, M (a black diamond worth at least 5,000 gp, which the spell consumes, and a corpse within range)  
**Duration:** Instantaneous  
**School:** Necromancy  
**Attack/Save:** None  
**Damage/Effect:** Summoning

**Spell Description:**  
Master's Call of the Undead is an advanced necromantic spell that transcends the boundaries of common undead creation, allowing the caster to summon forth beings of considerable power from the realm of death. This spell grants the necromancer the ability to infuse a corpse with dark energies, resurrecting it not as a mere zombie or skeleton, but as a formidable undead creature such as a Death Knight, a Wraith, or other powerful undead entities, at the DM's discretion.

Upon casting, the necromancer selects a corpse within range. The spell consumes the corpse and the black diamond, channeling a vortex of necrotic energy that cloaks the area in darkness. As the darkness dissipates, the chosen undead creature rises, bound to serve the caster. The type of undead created depends on the DM's guidelines and the nature of the campaign, but it is significantly more powerful than those summoned by lower-level necromantic spells.

The summoned undead remains under the control of the caster, obeying their commands to the best of its ability. The necromancer can command it verbally, requiring no action on their part, within a range of 100 feet. If the necromancer commands the undead to perform a task that would take it more than 100 feet away from them, the creature completes the task to the best of its ability and then returns to the necromancer.

The undead creature serves the caster indefinitely, but the necromancer can only have one such creature under their control at a time. Casting Master's Call of the Undead again while another powerful undead is under the caster's control will release the first creature from service, causing it to return to the afterlife.