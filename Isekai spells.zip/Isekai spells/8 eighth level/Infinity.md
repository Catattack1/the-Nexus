**Level:** 8th  
**Casting Time:** 1 action  
**Range/Area:** Self  
**Components:** V, S, M (a crystal that has been in a lunar and solar eclipse, worth at least 1,000 gp, which the spell consumes)  
**Duration:** 1 minute  
**School:** Transmutation  
**Attack/Save:** None  
**Damage/Effect:** Buff/Debuff

**Spell Description:**  
Upon casting Infinity, you channel the cosmic balance of limitless power and inevitable consequence into your very being. For the duration of this spell, you gain the following benefits:

- Your Strength, Dexterity, and Constitution scores increase to 24, regardless of their current values.
- You gain proficiency in all saving throws.
- Your movement speed is doubled.
- You gain a +2 bonus to AC.
- You have advantage on all attack rolls, saving throws, and ability checks.

However, the immense power of Infinity comes with a significant cost. When the spell ends, you suffer from the following drawbacks for the next 24 hours:

- Your Strength, Dexterity, and Constitution scores are reduced to 10, regardless of their natural values.
- You lose proficiency in all saving throws if you had it only due to this spell.
- Your movement speed is halved.
- You have disadvantage on all attack rolls, saving throws, and ability checks.

Infinity embodies the ultimate gamble, offering unparalleled power at the risk of severe vulnerability. This spell is a testament to those willing to embrace both the zenith of their potential and the nadir of their abilities, a dual-edged sword that demands respect and fear in equal measure.

**Special Note:** Due to the severe effects of this spell, it is recommended that it be used with great caution and strategic foresight, as its aftermath could leave the caster significantly impaired, potentially at the mercy of their foes or in a precarious situation requiring aid from their allies.