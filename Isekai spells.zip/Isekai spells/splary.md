**Level:** 
**Casting Time:** 
**Range/Area:** 
**Components:**   
**Duration:** 
**School:**  
**Attack/Save:** 
**Damage/Effect:** 

**Spell Description:**  


**At Higher Levels.** 
