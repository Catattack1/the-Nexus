### The Army of the Eternal Eclipse: Total Forces

1. **Archliches and Lich Queens (Commanders):** 500 - The supreme leaders, each wielding arcane powers that can shape or destroy worlds.
    
2. **Tarrasque (Vanguard):** 100 - A singular force of nature, but its sheer power counts for thousands.
    
3. **Ancient Prismatic Dragons (Air Superiority):** 20,000 - Masters of the sky, their breath can unleash cataclysmic destruction.
    
4. **Demigod Champions (Elite Infantry):** 5000 - Each a hero of myth, invulnerable to lesser foes and capable of feats that defy imagination.
    
5. **Void Sentinels (Special Forces):** 50,000 - From the void between worlds, they bring silence to magic and despair to their foes.
    
6. **Infernal War Machines (Siege Engines):** 10,000 - Crafted in the fires of perdition, these engines of war can obliterate cities in infernal fire.
    
7. **Army of the Damned (Unending Horde):** 2,900,000 - An endless tide of undead, capable of overwhelming any defense through sheer numbers.
    
8. **Mirror Golems (Defense):** 50,000 - Impenetrable guardians, their reflective surfaces turn any attack back upon the attacker.
    
9. **Celestial Avatars (Divine Intervention):** 600 - Beings of pure light and divine wrath, answering only to the highest powers.
    
10. **Primordial Elementals (Forces of Nature):** 60,000 - Embodiments of the elemental chaos, their presence alone can tear the fabric of reality.
    
11. **Shadow Assassins (Infiltration Unit):** 4,000 - Masters of stealth and death, capable of eliminating high-value targets in complete silence.
    
12. **Arcane Scholars (Magical Support):** 5,000 - Custodians of forbidden knowledge, weaving spells that can alter the course of battles.
    
13. **Draconic Sorcerers (Draconic Fury):** 100 - Descendants of dragons, their magic is bolstered by their ancient bloodline.
    
14. **Temporal Wardens (Time Manipulators):** 500 - Guardians of time, capable of undoing enemy actions or hastening the army's movements.

16. 1. **Galactic Leviathans (Cosmic Beasts):** 100 - New additions, these beings traverse the vacuum of space, capable of swallowing stars and devastating planets.
    
2. **Interdimensional Horrors (Eldritch Units):** 10,000 - Entities from beyond the known planes of existence, their mere presence warping reality and driving foes to madness.
    
3. **Celestial Choruses (Harmonizers of Fate):** 2,000 - Angelic beings whose songs can heal allies or wreak havoc upon enemies, altering the fate of those who hear them.
    

### Additional Insanities: