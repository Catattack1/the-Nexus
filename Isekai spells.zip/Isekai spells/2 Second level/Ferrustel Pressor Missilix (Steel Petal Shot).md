**Level:** 2nd  
**Casting Time:** 1 action  
**Range/Area:** Self (15 ft cone)  
**Components:** V, S, M (flowers in bloom within the area, which are not consumed)  
**Duration:** Instantaneous  
**School:** Transmutation  
**Attack/Save:** DEX Save  
**Damage/Effect:** Piercing

**Spell Description:**  
By harnessing the latent energy within the blooming flowers around you, you transmute their delicate petals into a barrage of razor-sharp steel shards. As you cast Ferrustel Pressor Missilix, or Steel Petal Shot, the air fills with the metallic scent of iron, and the gentle petals morph into a lethal storm directed in a cone before you.

Each creature in a 15-foot cone must make a Dexterity saving throw. A creature takes 3d6 piercing damage on a failed save, or half as much damage on a successful one. The steel shards created by this spell are magical and dissipate into thin air after striking or missing their target, leaving no physical trace of their existence save for the wounds they inflict.

This spell does not harm the flowers used as its material component, reflecting the magic's ability to borrow nature's beauty for a moment of deadly force without diminishing the natural world.

**At Higher Levels.** When you cast this spell using a spell slot of 3rd level or higher, the damage increases by 1d6 for each slot level above 2nd.