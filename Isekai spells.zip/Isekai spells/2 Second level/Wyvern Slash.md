**Level:** 2nd  
**Casting Time:** 1 bonus action  
**Range/Area:** Self (20 ft line, 5 ft wide)  
**Components:** V, S  
**Duration:** Instantaneous  
**School:** Evocation  
**Attack/Save:** Melee Weapon Attack  
**Damage/Effect:** Slashing

**Spell Description:**  
Charging your blade with the ferocious might of a wyvern, you unleash a devastating slash, launching a visible, arc-shaped, ethereal blade toward your foes. As you swing your weapon, a 5-foot-wide, ethereal, draconic energy projectile extends from it, slicing through the air in a straight line up to 20 feet away. Each creature in the projectile's path must make a Dexterity saving throw. On a failed save, a creature takes 3d8 slashing damage, plus any additional effects based on your class or abilities, and is pushed 5 feet away from the line's direction. On a successful save, a creature takes half as much damage and isn't pushed.

The ethereal blade passes through non-living matter without affecting it, allowing this spell to be used in crowded environments without collateral damage. However, it cannot penetrate total cover. If the initial attack roll is a critical hit, the spell's damage against the first target in the line is doubled, and the push effect increases to 10 feet.

**At Higher Levels.** When you cast this spell using a spell slot of 3rd level or higher, the damage increases by 1d8 for each slot level above 2nd.