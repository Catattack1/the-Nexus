**Level:** 2nd  
**Casting Time:** 1 bonus action  
**Range/Area:** 60 ft  
**Components:** V, S  
**Duration:** Instantaneous  
**School:** Necromancy  
**Attack/Save:** None  
**Damage/Effect:** Healing

**Spell Description:**  
Sacrifice Undead is a spell that exemplifies the pragmatic use of necromancy, turning the unlife force that animates the undead into a source of healing. By performing this dark rite, you target one undead minion under your control within 60 feet and willingly end its existence, causing its form to collapse into dust as its necrotic energy is redirected.

The target of this transferred energy, which can be you or an ally within range, is enveloped in a fleeting, shadowy aura before their wounds begin to mend, restoring hit points equal to twice the undead minion's remaining hit points up to a maximum of the minion's total hit points at the time of its summoning. This spell cannot exceed healing 4d8 hit points at its base level.

**At Higher Levels.** When you cast this spell using a spell slot of 3rd level or higher, the maximum amount of healing increases by 1d8 for each slot level above 2nd.

