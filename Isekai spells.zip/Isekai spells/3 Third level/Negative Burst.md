**Level:** 3rd  
**Casting Time:** 1 action  
**Range/Area:** Self (40 ft radius)  
**Components:** V, S  
**Duration:** Instantaneous  
**School:** Necromancy  
**Attack/Save:** CON Save  
**Damage/Effect:** Necrotic

**Spell Description:**  
By invoking the darker aspects of magical energy, you release a sudden, expanding wave of dark power from your own being. This pulse of negative energy extends in a 40-foot radius sphere centered on yourself, enveloping friends and foes alike within its dark embrace. The energy is indiscriminate, seeking to drain the life force from anyone caught in its expanse.

Each creature within the area, excluding you, must make a Constitution saving throw. On a failed save, a creature takes 3d8 necrotic damage, and you gain temporary hit points equal to half the total damage dealt by the spell, distributed amongst the affected targets. On a successful save, a creature takes half damage, and you gain no temporary hit points for that individual's resisted damage.

The spell's necrotic energy is capable of passing through non-living matter, affecting only living creatures. It does not damage objects or structures.

**At Higher Levels.** When you cast this spell using a spell slot of 4th level or higher, the damage increases by 1d8 for each slot level above 3rd.