**Level:** 3rd  
**Casting Time:** 1 action  
**Range/Area:** 60 ft (20 ft radius)  
**Components:** V, S, M (a fragment of bone and a pinch of grave dirt)  
**Duration:** Concentration, up to 1 minute  
**School:** Necromancy  
**Attack/Save:** DEX Save  
**Damage/Effect:** Necrotic/Control

**Spell Description:**  
Upon casting Grave's Call, you evoke the chilling power of the underworld to summon skeletal hands from the ground within a specified area. These ghostly appendages reach out from the earth, targeting all enemies within a 20-foot radius centered on a point you can see within 60 feet.

Each creature in the area when the spell is cast must succeed on a Dexterity saving throw or be caught by the skeletal hands. On a failed save, a creature takes 1d6 necrotic damage and its movement speed is halved for the duration. Creatures that succeed on their saving throw are unaffected by the reduction in movement speed but still suffer half damage (rounded up). At the start of each of the caster's turns while the spell is active, affected creatures take an additional 1d6 necrotic damage.

The skeletal hands grasp and claw at the targets, hindering their movement with a macabre persistence. This spell does not affect creatures that are flying or otherwise not in contact with the ground.

**At Higher Levels.** When you cast this spell using a spell slot of 4th level or higher, the radius of the area increases by 5 feet, and the damage by 1d6, for each slot level above 3rd.