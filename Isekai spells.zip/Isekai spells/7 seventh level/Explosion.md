**Level:** 7th  
**Casting Time:** Concentration, up to 1 minute  
**Range/Area:** 1 mile (Special radius)  
**Components:** V, S, M (a pinch of powdered ruby worth at least 500 gp, which the spell consumes)  
**Duration:** Instantaneous  
**School:** Evocation  
**Attack/Save:** DEX Save  
**Damage/Effect:** Fire/Force

**Spell Description:**  
Upon casting Explosion, you begin to channel raw, volatile energy, focusing intently on a point you can see within a mile. The air around you shimmers with heat as you concentrate, and the ground beneath you thrums with power. This spell requires your unwavering focus; any interruption causes the spell to fail, and the energy dissipates harmlessly.

The power of the explosion, and the area it affects, scales with how long you maintain concentration:

- **30 seconds or less:** The explosion covers a 20-foot-radius sphere, dealing 6d6 fire damage and 6d6 force damage.
- **4 minute:** The explosion covers a 40-foot-radius sphere, dealing 20d6 fire damage and 20d6 force damage.

Each creature in the affected area must make a Dexterity saving throw. A creature takes full damage on a failed save, or half as much damage on a successful one. Structures and nonmagical objects in the blast area are also affected, potentially being destroyed or severely damaged by the force of the explosion.

The spell's immense detonation creates a thunderous boom audible up to 3 miles away. The sheer force of the explosion can create a crater if used on the ground, altering the terrain and potentially causing secondary hazards (DM's discretion).

**Special Consideration:** Given its destructive potential and the concentration required, casting Explosion leaves you exhausted. After the spell's completion, you suffer one level of exhaustion, reflecting the physical and mental strain of controlling such potent magic.