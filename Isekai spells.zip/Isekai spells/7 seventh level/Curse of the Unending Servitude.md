**Level:** 7th  
**Casting Time:** 1 action  
**Range/Area:** Touch  
**Components:** V, S, M (a talisman made from the bone of an undead creature, worth at least 1,000 gp, which the spell consumes)  
**Duration:** Permanent until dispelled  
**School:** Necromancy  
**Attack/Save:** Melee Spell Attack  
**Damage/Effect:** Curse/Summoning

**Spell Description:**  
Curse of the Unending Servitude is a powerful and malevolent spell that binds the essence of a slain creature to the will of the caster, forcing it into a grotesque semblance of life as an undead servant. When you touch a living creature with the intent to kill, you make a melee spell attack against it. If the attack hits and the creature is slain by the damage caused by this spell or dies within 1 minute of being touched, the curse takes effect.

**Effects:**

- **Resurrection as Undead:** The slain creature is resurrected at the start of your next turn as an undead creature. The type of undead it becomes (zombie, skeleton, ghoul, etc.) is at the DM's discretion, based on the creature's original form and the circumstances of its death.
- **Bond of Servitude:** The resurrected undead is permanently bound to your will, following your verbal commands to the best of its ability. It gains a bonus to its attack rolls, damage rolls, and AC equal to your spellcasting ability modifier. The undead servant acts on your turn in combat.
- **Mark of Servitude:** The undead servant bears a visible mark of your necromantic power, making its nature and allegiance unmistakable. This mark is a symbol of your choice that appears somewhere on the undead's body.

**Dispelling the Curse:** The curse can be dispelled only by a spell such as _remove curse_ cast at a level equal to or higher than the level of _Curse of the Unending Servitude_. Destroying the undead servant does not remove the curse from the creature's soul; a proper _dispel magic_ or _remove curse_ must be used to free it completely.