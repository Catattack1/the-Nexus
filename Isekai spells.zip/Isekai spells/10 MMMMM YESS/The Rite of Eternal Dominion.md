**Level:** Archmage Ritual  
**Casting Time:** 1 lunar cycle (28 days)  
**Range/Area:** Special  
**Components:** V, S, M (a gem worth at least 100,000 gp, the heart of a dragon aged at least 1,000 years, a tome bound in the skin of a saint, and the blood of the caster, willingly given each day of the ritual)  
**Duration:** Until completed  
**School:** Necromancy  
**Attack/Save:** None  
**Damage/Effect:** Transformation

**Spell Description:**  
The Rite of Eternal Dominion is an arcane process so complex and demanding, it borders on the realm of forbidden lore. This ritualistic spell allows a caster to transcend mortality by becoming a lich, but the path to such dark immortality is fraught with peril, requiring not only immense magical power but also a willingness to forsake one's humanity and embrace the eternal darkness.

**Preparation Phase (Days 1-7):**

- **Location:** Must be performed in a place of great power, such as a ley line nexus or ancient ruins, sanctified with the blood of the caster each day.
- **Material Preparation:** The gem, acting as the future phylactery, must be bathed in the blood of a celestial being under the light of a full moon, then encased in the heart of the dragon, preserving the gem's purity and the dragon's essence.

**Summoning Phase (Days 8-14):**

- **Celestial Opposition:** Summon and bind a celestial being, forcing it to bear witness to the ritual, thus ensuring the balance of cosmic forces.
- **Arcane Inscription:** The tome bound in saint's skin must be inscribed with spells of protection, binding, and necromancy, using ink made from the caster's blood mixed with ashes from the Tree of Life.

**Transformation Phase (Days 15-21):**

- **Dragon's Heart Alchemy:** The dragon's heart, encasing the gem, must be submerged in a cauldron filled with the rarest magical reagents (including phoenix feathers, unicorn horn powder, and the essence of a shadow) and cooked over a flame kindled from an everburning fire.
- **Soul Binding:** The caster must willingly cut their palm each day, letting their blood flow over the dragon's heart, creating a bond between their soul and the forming phylactery.

**Ascension Phase (Days 22-28):**

- **Final Incantations:** With the celestial being as a witness, the caster must recite incantations that echo through the planes, sealing their fate.
- **Eternal Dominion:** On the final night, under a new moon, the caster consumes the alchemically transformed dragon's heart, thus transferring their essence into the gem. The process is agonizing and tests the caster's resolve, as they must willingly embrace death to be reborn as a lich.

**Result:**  
The completion of The Rite of Eternal Dominion severs the caster's ties to life, rebirthing them as a lich. Their soul, now housed within the phylactery, grants them power over death itself, at the cost of their mortal essence and the eternal enmity of celestial beings.

**Warnings:**

- Failure at any step of the ritual results in the caster's instant death and the potential release of a catastrophic arcane backlash.
- The process is irrevocable; once begun, it must be completed or perish.