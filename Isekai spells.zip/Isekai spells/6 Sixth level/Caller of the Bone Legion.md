**Level:** 6th  
**Casting Time:** 1 minute  
**Range/Area:** 150 ft (50 ft radius)  
**Components:** V, S, M (a handful of bones from at least three different creatures and a drop of the caster's blood)  
**Duration:** Concentration, up to 1 hour  
**School:** Necromancy  
**Attack/Save:** None  
**Damage/Effect:** Summoning

**Spell Description:**  
Caller of the Bone Legion is a formidable spell that allows a necromancer to summon forth a legion of skeletal warriors from the earth itself. These skeletal entities are not mere mindless undead but disciplined soldiers from ages past, reanimated with a portion of their former tactical acumen and fighting prowess. Upon casting, the ground within the spell's vast area trembles and fractures, as skeletal warriors equipped with ethereal armor and weapons rise to form a phalanx at the caster's command.

You conjure 10 skeletal warriors within a 50-foot radius. These skeletons are equipped with spectral weapons and shields, capable of forming shield walls, executing flanking maneuvers, and performing coordinated strikes against your enemies. They follow your verbal commands to the best of their ability, acting on your turn in combat. Each skeleton has hit points equal to a standard skeleton but deals an additional 1d6 necrotic damage on a hit due to their ethereal weapons.

The skeletons can defend positions, charge enemies, or protect individuals within their ranks. Their ability to form a shield wall grants them and any allies behind the wall half cover against attacks from the front. If not given any commands, the skeletons defend themselves from attackers but otherwise do not act.

**At Higher Levels.** When you cast this spell using a spell slot of 7th level or higher, you summon an additional 5 skeletal warriors for each slot level above 6th.