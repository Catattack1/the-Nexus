**Level:** 6th  
**Casting Time:** 1 hour  
**Range/Area:** Touch  
**Components:** V, S, M (a piece of the creature whose part is being grafted, along with rare alchemical reagents worth at least 500 gp, which the spell consumes)  
**Duration:** Permanent  
**School:** Necromancy  
**Attack/Save:** None  
**Damage/Effect:** Enhancement

**Spell Description:**  
Necrotic Graft is a complex and darkly innovative spell that pushes the boundaries of necromancy into the realm of the grotesque yet wondrous. This spell allows the caster to fuse parts from various corpses—be they dragon scales, the wings of a gryphon, or the claws of a werewolf—onto an undead creature they control, integrating these parts seamlessly as if they were a natural component of the undead's form.

Upon casting Necrotic Graft, the caster selects an undead creature under their control and a corpse part to graft onto it. The spell meticulously knits the chosen appendage or feature onto the undead, imbuing it with the necessary necrotic energy to animate and incorporate the new part into its physiology. This process not only grafts the physical aspect but also transfers any innate abilities associated with the part to the undead recipient, subject to the DM's discretion.

For example, grafting dragon wings onto a zombie might grant it the ability to fly, while attaching a basilisk's gaze organ could bestow a petrifying gaze attack. The possibilities are as varied as the creatures from which parts can be harvested, offering a deeply customizable approach to undead creation.

**Limitations:**

- The spell can only graft parts from non-undead creatures.
- The undead's body might reject the graft if it is too powerful or incompatible, at the DM's discretion.
- There's a limit to how many grafts an undead can sustain, typically one major graft (like wings or a gaze organ) or two to three minor grafts (like claws or fangs).