**Level:** 9th  
**Casting Time:** 1 hour  
**Range/Area:** 1 mile  
**Components:** V, S, M (an orb crafted from obsidian and bone, worth at least 25,000 gp, which is consumed by the spell; the ashes of a phoenix; and the blood of a fiend)  
**Duration:** 24 hours  
**School:** Necromancy  
**Attack/Save:** None  
**Damage/Effect:** Summoning/Control

**Spell Description:**  
Apocalypse of the Damned is a cataclysmic spell of terrifying power and scope, designed to unleash an undead scourge upon the land. By invoking this spell, the caster taps into the darkest necromantic energies, transforming the area into a nightmarish landscape overrun by legions of undead. The very earth splits and graveyards vomit forth their dead as a malignant force animates them, creating an army of undead creatures under the caster's command.

**Effects:**

- **Undead Legion:** Summons 100 skeletons, 50 zombies, 10 wights, and 5 death knights within a 1-mile radius. These undead are bound to the caster's will, obeying their commands without question.
- **Corrupted Land:** The area becomes blighted, with vegetation withering away, waters turning black and poisonous, and the sky darkening with ominous clouds. Living creatures within the area suffer from unease and terror, and the land becomes inhospitable to life.
- **Necrotic Storms:** Dark clouds form above, periodically unleashing necrotic storms that rain down black energy, capable of reanimating small animals and insects as undead servants of the caster.
- **Aura of Despair:** All living beings within the area suffer disadvantage on saving throws against fear and necromancy spells cast by the spellcaster.

**Ending the Spell:** The spell lasts for 24 hours, after which the undead horde crumbles to dust, and the blighted land begins a slow recovery process. However, the land's recovery can take decades or even centuries. The caster can also choose to end the spell early by performing a 1-minute ritual that requires the caster to willingly sacrifice a portion of their own life force (reducing their maximum hit points by 10% until they complete a long rest).

**Consequences:** Casting Apocalypse of the Damned is an act of immense evil that leaves a permanent scar on the natural world and the caster's soul. It is likely to attract the attention of powerful forces, both divine and arcane, who seek to prevent such catastrophic power from being unleashed.

**Use with Caution:** This spell is intended for use in scenarios where the moral and ethical implications can be fully explored, as its casting is a significant event with lasting consequences for any campaign world.