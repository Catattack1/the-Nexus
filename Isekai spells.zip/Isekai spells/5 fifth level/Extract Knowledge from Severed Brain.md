### Spell: **Extract Knowledge from Severed Brain**

**Level:** 5th  
**School:** Necromancy  
**Casting Time:** 1 hour (Ritual)  
**Range:** Touch  
**Components:** V, S, M (a silver needle, a vial of alchemical solvent, a pinch of powdered amethyst, and a black candle)  
**Duration:** Instantaneous

**Description:**

This ritual allows the caster to extract knowledge from the brain of a deceased creature, provided the brain has been severed from the body within the past 7 days. The spell grants the caster the ability to delve into the memories and knowledge that the creature possessed at the time of death.

**Procedure:**

1. **Preparation:** The caster must first purify the brain using the alchemical solvent, cleansing it of any remaining blood or impurities. This process takes 10 minutes and must be done carefully to avoid damaging the brain further.
    
2. **Invocation:** The caster lights the black candle and places it beside the brain. They then chant the incantation while holding the silver needle above the brain. The powdered amethyst is sprinkled over the brain during the incantation, which should take approximately 50 minutes.
    
3. **Extraction:** At the culmination of the ritual, the caster plunges the silver needle into the brain. The brain briefly glows with a faint purple light as the memories and knowledge are drawn out.
    

**Effects:**

- The caster gains access to one specific piece of knowledge or a memory that was of significant importance to the creature. This could be the location of a hidden treasure, a password, a crucial conversation, or any other piece of information the creature knew.
    
- The spell does not allow the caster to see all of the creature's memories; rather, it grants insight into the knowledge or memories most closely related to the caster’s intended inquiry.
    
- If the brain has been severely damaged or if more than 7 days have passed since the creature's death, the spell has a high chance of failure. In such cases, the caster must make a DC 15 Intelligence (Arcana) check. On a failure, the information is lost, and the brain is rendered unusable for further attempts.
    

**Limitations:**

- This spell cannot be used to extract information that the creature itself did not know or was not aware of at the time of death.
- The knowledge gained is based on the creature’s perception and may be subject to its biases or misunderstandings.
- Repeated use of this spell on the same brain yields no additional information unless the caster seeks different knowledge each time.

**At Higher Levels:** When casting this spell using a spell slot of 6th level or higher, the caster can extract one additional piece of information for each slot level above 5th.