**Level:** 5th  
**Casting Time:** 1 action  
**Range/Area:** Self  
**Components:** V, S, M (a quill made from a raven's feather, and ink mixed with the caster's own blood)  
**Duration:** 1 hour  
**School:** Necromancy  
**Attack/Save:** None  
**Damage/Effect:** Summoning

**Spell Description:**  
Necronomicon Conjuration is a unique spell that calls forth a spectral tome of necromantic knowledge, serving as a spellcasting focus specifically for necromancy spells. This ethereal book is imbued with ancient and dark magic, allowing the caster to tap into its power to enhance their necromantic spellcasting abilities.

**Effects:**

- **Spellcasting Focus:** The Necronomicon serves as a spellcasting focus for the caster, but only for necromancy spells. While holding or having the tome on their person, the caster gains a +2 bonus to spell attack rolls and the saving throw DCs for their necromancy spells.
- **Necrotic Insight:** Once per duration of the spell, the caster can consult the Necronomicon for guidance on a necromancy spell they are about to cast. Doing so grants the spell one of the following benefits (caster's choice):
    - Reduce the spell's level by one, to a minimum of 1st level, without reducing its effects.
    - Increase the spell's effective level by one, enhancing its effects as if a higher-level spell slot had been used, without actually consuming a higher-level slot.
    - Extend the duration of a necromancy spell that has a duration of 1 minute or longer by 50%.
- **Spectral Guardian:** The Necronomicon is protected by a spectral guardian that can ward off those unworthy or hostile towards the caster. If an enemy attempts to seize or destroy the tome, the guardian imposes disadvantage on their attack rolls against the tome.