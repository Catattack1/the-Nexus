**Level:** 5th  
**Casting Time:** 1 action  
**Range/Area:** 30 ft  
**Components:** V, S  
**Duration:** Instantaneous  
**School:** Necromancy  
**Attack/Save:** CON Save  
**Damage/Effect:** Necrotic/Paralysis

**Spell Description:**  
Soul Rend is a chilling incantation that targets the very essence of life within a creature. By casting this spell, you reach out with a spectral hand, visible only as a shimmering distortion in the air, to grasp the soul of one enemy within range. The touch of this hand is an intrusion few can withstand without consequence.

The target must make a Constitution saving throw. On a failed save, the creature suffers 4d8 necrotic damage and is paralyzed for up to 1 minute, as the pain and shock of having their life force wrenched at overwhelms their physical form. At the end of each of its turns, the target can make another Constitution saving throw, ending the effect on itself on a success.

On a successful save, the target takes half damage and is not paralyzed but may still feel a fleeting, excruciating pain that echoes the touch of death.

**At Higher Levels.** When you cast this spell using a spell slot of 6th level or higher, the damage increases by 1d8 for each slot level above 5th.