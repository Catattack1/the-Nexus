**Level:** 5th  
**Casting Time:** 1 action  
**Range/Area:** 25 ft (30 ft radius)  
**Components:** V, S, M (a prism and a feather from a white dove)  
**Duration:** 1 round  
**School:** Evocation  
**Attack/Save:** DEX Save  
**Damage/Effect:** Radiant

**Spell Description:**  
With a word and a gesture, you conjure a small, dense orb of glowing white energy and send it to a point you choose within range. This orb floats in place for a brief moment, radiating a soft, humming power. At the start of your next turn, the orb detonates in a blinding explosion of white light, expanding to fill a 30-foot-radius sphere.

Each creature in the area of the explosion must make a Dexterity saving throw. On a failed save, a creature takes 8d6 radiant damage and is blinded until the end of its next turn. On a successful save, a creature takes half as much damage and isn't blinded. Nonmagical objects in the area that aren't being worn or carried also take this damage, and the area is illuminated as if by daylight for 1 minute after the explosion.

This spell's damage ignores resistances but not immunities. The intense radiance of the White Nova pierces through most defenses, reflecting its near-unstoppable nature. Creatures with vulnerability to radiant damage take double damage on a failed save and normal damage on a successful one.

**At Higher Levels.** When you cast this spell using a spell slot of 6th level or higher, the damage increases by 1d6 for each slot level above 5th.