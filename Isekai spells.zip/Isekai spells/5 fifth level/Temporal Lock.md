### Spell: **Temporal Lock**

**Level:** 5th  
**School:** Abjuration  
**Casting Time:** 1 action  
**Range:** Touch  
**Components:** V, S, M (a small piece of quartz crystal and a drop of resin)  
**Duration:** Up to 1 month (See below)

**Description:**

You touch a creature or object and place it into a state of suspended animation. For the duration of the spell, the target is in a state of temporal stasis and does not age, breathe, eat, drink, or move. Time effectively stops for the target.

While in this state, the target is immune to all damage, cannot be harmed by any effect, and is considered incapacitated. Any ongoing effects, such as poison or disease, are halted for the duration but resume normally once the spell ends.

**Duration Details:**

- The duration of the spell is up to 30 days, but it requires the caster to maintain concentration each day to sustain the effect.
- If the caster fails to maintain concentration at any point, the spell ends immediately.
- The spell can be ended at any time by the caster as a bonus action.

**Limitations:**

- This spell can only be used on willing creatures or objects. If the target is unwilling, they must succeed on a Wisdom saving throw against the caster’s spell save DC to avoid the effect.
- This spell can only affect creatures or objects of a size no larger than Large.
- The spell cannot be used on creatures or objects already under a similar stasis effect.

**At Higher Levels:** When casting this spell using a spell slot of 6th level or higher, the maximum size of the creature or object affected increases by one size category for each slot level above 5th.