**Level:** 5th  
**Casting Time:** 1 action  
**Range/Area:** 60 ft  
**Components:** V, S, M (a piece of decayed armor and a handful of earth from a crypt)  
**Duration:** Concentration, up to 1 hour  
**School:** Necromancy  
**Attack/Save:** None  
**Damage/Effect:** Summoning/Protection

**Spell Description:**  
Crypt Guardian summons a formidable undead entity from the depths of ancient crypts, a sentinel of bygone eras revived to serve you. This guardian emerges from the ground, towering over most creatures, its form clad in pieces of decayed armor that hint at its noble past. In its hands, it wields a massive weapon, forged from the shadows of the underworld, ready to defend its charge.

Upon casting, you designate either a location or a person within range as the guardian's ward. The Crypt Guardian is bound to protect this ward with unyielding resolve. It positions itself strategically, always standing between its ward and potential threats, ready to strike at those who dare approach with hostile intent.

The Crypt Guardian has hit points equivalent to twice your wizard level + your spellcasting ability modifier. It has AC 16 due to its spectral armor and can make attacks using its massive weapon with a bonus to hit equal to your spellcasting ability modifier + your proficiency bonus, dealing 2d8 + your spellcasting ability modifier in damage on a hit. The guardian acts on your turn in combat and obeys any verbal commands you issue it (no action required by you), focusing primarily on protection but capable of executing other simple tasks.

If the guardian is destroyed, or if you end the spell, it crumbles into dust, leaving behind no physical trace of its presence. If the spell ends and the guardian is intact, it solemnly returns to the earth, as if stepping back into the shadows of history.

**At Higher Levels.** When you cast this spell using a spell slot of 6th level or higher, the guardian's hit points increase by 10, and its damage increases by 1d8 for each slot level above 5th.