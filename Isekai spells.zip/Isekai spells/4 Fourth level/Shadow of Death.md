**Level:** 4th  
**Casting Time:** 1 action  
**Range/Area:** 150 ft (30 ft radius)  
**Components:** V, S, M (a piece of obsidian and a shadow captured in a crystal vial)  
**Duration:** Concentration, up to 10 minutes  
**School:** Necromancy  
**Attack/Save:** CON Save  
**Damage/Effect:** Debuff/Buff

**Spell Description:**  
Shadow of Death is a powerful spell that blurs the boundary between offense and defense, casting a designated area into supernatural darkness. This darkness is not just a mere absence of light but a manifestation of necrotic energy that affects friend and foe differently. Upon casting, you target a point within range, and from this point, darkness spreads in a 30-foot radius, permeating the area with a chilling gloom.

Enemies within the area when the spell is cast must make a Constitution saving throw. On a failed save, they suffer a -1 penalty to attack rolls, damage rolls, and AC due to their strength being sapped by the shadowy energy. They also lose 5 feet from their movement speed, as the darkness weighs down upon them.

Allies within the darkness, conversely, find themselves oddly invigorated by its presence. They receive a +1 bonus to attack rolls, damage rolls, and AC, as well as an additional 5 feet to their movement speed, as the shadowy energy bolsters their resolve and agility.

The area covered by the Shadow of Death is considered heavily obscured for enemies, providing cover and making it difficult for them to see. Allies, however, perceive the darkness as a mere shadow over the landscape, allowing them to see through it as if it were natural dim light.

**At Higher Levels.** When you cast this spell using a spell slot of 5th level or higher, the radius of the affected area increases by 10 feet, and the penalties and bonuses increase by 1 for each slot level above 4th.