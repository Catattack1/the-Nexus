**Level:** 4th  
**Casting Time:** 1 action  
**Range/Area:** Self (60 ft cone)  
**Components:** V, S, M (a withered leaf and a drop of elder's blood)  
**Duration:** Instantaneous  
**School:** Necromancy  
**Attack/Save:** CON Save  
**Damage/Effect:** Necrotic/Debuff

**Spell Description:**  
With a gesture and a whispered incantation, you unleash a formidable wave of dark, necrotic energy in a 60-foot cone in front of you. This wave of decay is visible as a ghastly, shimmering arc, bringing a sensation of dread to those it envelops. All living beings caught in the wave are exposed to its malignant power, experiencing an unnatural acceleration of aging that saps their vitality and resilience.

Each creature in the area must make a Constitution saving throw. On a failed save, a creature takes 2d8 necrotic damage and suffers a -2 penalty to Strength and Constitution scores for 1 minute due to rapid aging. Additionally, their AC is reduced by 1 for the duration as their physical defenses are weakened. A successful save halves the damage and negates the reduction in Strength, Constitution, and AC.

The effects of rapid aging and weakened defenses are not cumulative from multiple exposures to Decay Wave, but the damage can stack with repeated castings. Creatures immune to aging, such as constructs and undead, are unaffected by the debuff but still take damage if they fail their saving throw.

**At Higher Levels.** When you cast this spell using a spell slot of 5th level or higher, the damage increases by 1d8 for each slot level above 4th.